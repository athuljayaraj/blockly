function f() {

}
f();
